__version__ = 0.1
print(f'udp.connection.secure.foundation Version: {__version__}')